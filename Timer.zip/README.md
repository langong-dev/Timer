# Timer
 
a Bash Alert Timer.

# How To Use It

Please install `langong-dev/LanFilePackage` .

```bash
./LanGong install github langong-dev/Timer
```

Run

```bash
./LanGong run Timer
```

# Install-Error

## 1. If You Haven't Got the folder of ```Timer/```

Please run it again.

## 2. If You Cannot Clone the Timer

Please check if you have a folder named ```Timer``` .

If you have it, you can rename it.

You haven't a folder named ```Timer``` , please check your Internet.

